<h2>Tambah Data</h2>

<form action="jenisobat_proses.php" method="post">
    <table>
        <tr>
            <td>Jenis Obat</td>
            <td><input type="text" name="jenisobat_nama" class="input-data"></td>
        </tr>
        <tr>
            <td></td>
            <td>
            <input type="submit" name="btn_simpan" value="SIMPAN">
            <input type="submit" name="btn_batal" value="BATAL">
            </td>
        </tr>
    </table>
</form>